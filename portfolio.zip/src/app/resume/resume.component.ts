import { Component } from '@angular/core';

@Component({
  selector: 'app-resume',
  standalone: true,
  imports: [],
  template: `
    <p>
      resume works!
    </p>
  `,
  styles: ``
})
export class ResumeComponent {

}
