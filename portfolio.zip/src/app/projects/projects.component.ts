import { Component } from '@angular/core';

@Component({
  selector: 'app-projects',
  standalone: true,
  imports: [],
  template: `
    <p>
      projects works!
    </p>
  `,
  styles: ``
})
export class ProjectsComponent {

}
