import { Component } from '@angular/core';

@Component({
  selector: 'app-pagenotfound',
  standalone: true,
  imports: [],
  template: `
    <p>
      pagenotfound works!
    </p>
  `,
  styles: ``
})
export class PagenotfoundComponent {

}
